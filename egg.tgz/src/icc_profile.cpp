// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply ICC profile\n", stdout);
  return lionss_run_workload("icc_profile");
}
