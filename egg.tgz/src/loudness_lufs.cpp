// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Measure integrated LUFS"); }
int main(){
  announce();
  return lionss_run_workload("loudness_lufs");
}
