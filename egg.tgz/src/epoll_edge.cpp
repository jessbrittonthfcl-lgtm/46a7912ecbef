// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Drive edge-triggered epoll"); }
int main(){
  announce();
  return lionss_run_workload("epoll_edge");
}
