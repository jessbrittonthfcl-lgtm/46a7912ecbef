// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reorder join tree"); }
int main(){
  announce();
  return lionss_run_workload("joinReorder");
}
