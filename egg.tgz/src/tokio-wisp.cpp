// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Spawn reactor tasks\n", stdout);
  return lionss_run_workload("tokio-wisp");
}
